// in separate file due to caching issue

// toggle hints, explanation and feedback (requires jquery library)
$(window).load(function () {
    $(".newStretchy").each(function () {

        var titleDiv = $(this).find(".title") ;
        var titleH3 = titleDiv.find("h3");
        var contentDiv = $(this).find(".content") ;


        // initialise title
        $(titleH3[1]).toggle();
        titleDiv.toggleClass('closed') ; // initially adds class closed

        //initially hide content div
        contentDiv.hide();

        // toggle appropriate classes
        $(titleDiv).find(".toggle").click(function () {

            var thisTitleDiv = titleDiv;

            titleH3.toggle(); // toggle button text

            // tidy css transitions by ordering
            if(thisTitleDiv.hasClass('closed'))
            {
                thisTitleDiv.toggleClass('closed');
                contentDiv.slideToggle( "slow");
            }
            else {
                contentDiv.slideToggle( "slow", function () {thisTitleDiv.toggleClass('closed') });
            }

        })
    });
});